TEST_FILE = 'tests/fixtures/lorem_ipsum.json'
TEST_FILE_CHECKSUMS = {
    'crc32c': '842b10aa',
    's3_etag': 'ddd80671f81b6e687bcaff02edea4c3b',
    'sha1': '39ba467330f87327eefb5a071b8dec213623c4e3',
    'sha256': 'c55de3986267db6fdf1e4e960e2db01781c67f328da26693b9ff4c7387c6e472'
}
